//读取
#include "comm.h"
using namespace std;
int main()
{
  umask(0);

  if(mkfifo(IPC_PATH, 0666) != 0)
  {
    cerr << "mkfifo error" << endl;
    return 1;
  }

  int pipeFd = open(IPC_PATH,O_RDONLY);
  if(pipeFd < 0)
  {
    cerr << "open fifo error" << endl;
    return 2;
  }
#define NUM 1024
  char buffer[NUM];
  //正常的通信过程
  while(true)
  {
    ssize_t s = read(pipeFd, buffer, sizeof(buffer) - 1);
    if(s > 0)
    {
      buffer[s] = '\0';
      cout << "客户端->服务器#" << buffer <<endl;
    }
    else if(s == 0)
    {
      cout << "客户退出啦， 我也退出把";
        break;
    }
    else
    {
      cout << "read :" << strerror(errno) << endl;
      break;
    }
  }

  close(pipeFd);
  cout << "服务器退出啦" << endl;
  unlink(IPC_PATH);
  return 0;
}
