#pragma once

#include <stdio.h>
#include <assert.h>

extern int addToVal(int from, int to);
