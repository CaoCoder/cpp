#include "mymath.h"

int addToVal(int from, int to)
{
  assert(from <= to);

  int result = 0;
  int i = 0;
  for(i = from; i <= to;i++)
  {
    result += i;

  }

  return result;
}
