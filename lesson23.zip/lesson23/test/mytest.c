#include "mymath.h"
#include "myprint.h"

int main()
{
  int start = 0;
  int end = 100;

  int result = addToVal(start, end);
  printf("result:%d\n", result);
  Print("hello");

  return 0;
}
