#pragma once
#include <stdio.h>
#include <time.h>

extern void Print(const char* msg);
